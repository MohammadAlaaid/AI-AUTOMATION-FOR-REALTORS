CREATE POLICY "Server manages contact requests"
ON public.contact_requests
FOR ALL
TO service_role
USING (true)
WITH CHECK (true);