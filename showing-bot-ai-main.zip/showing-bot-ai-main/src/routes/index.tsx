import { useEffect, useState, type FormEvent } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { FaCalendarCheck, FaChartColumn, FaCommentSms, FaPhoneVolume } from "react-icons/fa6";
import { FaDiscord, FaFacebook, FaGraduationCap, FaInstagram, FaSnapchatGhost, FaTiktok, FaYoutube } from "react-icons/fa";
import { SiThreads } from "react-icons/si";

import portraitAsset from "@/assets/mohammad-portrait.png.asset.json";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { submitContactRequest } from "@/lib/contact.functions";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AI Voice Receptionist for Realtors | Mohammad Alaaid" },
      { name: "description", content: "AI voice receptionists that answer every call and book real estate showings 24/7." },
      { property: "og:title", content: "AI Voice Receptionist for Realtors | Mohammad Alaaid" },
      { property: "og:description", content: "AI voice receptionists that answer every call and book real estate showings 24/7." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const features = [
  { icon: FaPhoneVolume, title: "24/7 Call Answering", description: "Every call answered. Nights, weekends, holidays." },
  { icon: FaCalendarCheck, title: "Auto Calendar Booking", description: "Showings booked directly into your Google Calendar." },
  { icon: FaCommentSms, title: "SMS Confirmations", description: "Clients get instant text confirmations and reminders." },
  { icon: FaChartColumn, title: "Daily Email Reports", description: "A summary of every call and booking, in your inbox daily." },
];

const socials = [
  { label: "Instagram", href: "https://instagram.com/mohammadalaaid", icon: FaInstagram },
  { label: "YouTube", href: "https://www.youtube.com/@MohammadAlaaid", icon: FaYoutube },
  { label: "Threads", href: "https://www.threads.com/@mohammadalaaid", icon: SiThreads },
  { label: "TikTok", href: "https://tiktok.com/@mohammadalaaid", icon: FaTiktok },
  { label: "Snapchat", href: "https://www.snapchat.com/@mohammad.alaaid", icon: FaSnapchatGhost },
  { label: "Discord", href: "https://discord.gg/BCHsfnwk6", icon: FaDiscord },
  { label: "Skool", href: "https://www.skool.com/@mohammad-alaaid-8015", icon: FaGraduationCap },
  { label: "Facebook", href: "https://www.facebook.com/MohammadAlaaid/", icon: FaFacebook },
];

function Index() {
  useEffect(() => {
    const nodes = document.querySelectorAll<HTMLElement>("[data-reveal]");
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((entry) => entry.isIntersecting && entry.target.classList.add("is-visible")),
      { threshold: 0.12 },
    );
    nodes.forEach((node) => observer.observe(node));
    return () => observer.disconnect();
  }, []);

  return (
    <main id="top" className="min-h-screen bg-background text-foreground">
      <Navigation />

      <section className="relative flex min-h-[760px] items-center overflow-hidden border-b border-border/60 px-5 pb-16 pt-24 sm:px-8 lg:min-h-[min(920px,calc(100svh-4rem))]">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_20%,var(--brand-navy),transparent_42%)] opacity-45" />
        <div className="relative mx-auto flex w-full max-w-5xl flex-col items-center text-center">
          <p className="mb-7 text-xs font-semibold uppercase text-muted-foreground sm:text-sm">AI AUTOMATION FOR REALTORS</p>
          <img src={portraitAsset.url} alt="Mohammad Alaaid" width="200" height="200" fetchPriority="high" className="mb-7 size-40 rounded-full border border-border object-cover sm:size-[200px]" />
          <h1 className="text-5xl font-extrabold leading-none sm:text-6xl">Mohammad Alaaid</h1>
          <p className="mt-7 max-w-4xl text-2xl font-semibold leading-[1.4] sm:text-3xl">
            I watched an agent lose an $8,000 commission because they missed a call. That changed everything. Now I build AI systems to make sure it never happens again.
          </p>
          <div className="mt-9 flex w-full flex-col justify-center gap-3 sm:w-auto sm:flex-row">
            <Button asChild variant="hero" size="hero"><a href="#contact">Book a Call</a></Button>
            <Button asChild variant="heroOutline" size="hero"><a href="#what-i-do">See How It Works</a></Button>
          </div>
          <p className="mt-6 text-sm text-social">✓ First clients booked showings within 48 hours.</p>
        </div>
      </section>

      <section id="what-i-do" className="px-5 py-24 sm:px-8 sm:py-32">
        <div className="mx-auto max-w-6xl">
          <div data-reveal className="reveal mx-auto max-w-5xl text-center">
            <h2 className="text-3xl font-bold leading-tight sm:text-5xl">Every call answered. Every lead booked. Every opportunity captured.</h2>
            <p className="mx-auto mt-6 max-w-3xl text-base leading-8 text-muted-foreground sm:text-lg">First clients booked showings within 48 hours. Average result: 2-3 new bookings per week per agent.</p>
          </div>
          <div className="mt-14 grid gap-4 md:grid-cols-2">
            {features.map(({ icon: Icon, title, description }) => (
              <article key={title} data-reveal className="reveal rounded-lg border border-border bg-surface p-8">
                <Icon aria-hidden="true" className="size-10 text-foreground" />
                <h3 className="mt-8 text-2xl font-bold">{title}</h3>
                <p className="mt-3 text-base leading-7 text-muted-foreground">{description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="pricing" className="border-y border-border/60 px-5 py-24 sm:px-8 sm:py-32">
        <div data-reveal className="reveal mx-auto max-w-2xl">
          <h2 className="text-center text-4xl font-bold sm:text-5xl">Pricing</h2>
          <div className="mt-12 rounded-lg border border-border bg-surface p-7 sm:p-12">
            <div className="grid gap-8 sm:grid-cols-2 sm:gap-12">
              <div><p className="text-5xl font-bold sm:text-6xl">$250</p><p className="mt-2 text-sm text-muted-foreground">one-time setup</p></div>
              <div><p><span className="text-5xl font-bold sm:text-6xl">$99</span> <span className="text-sm text-muted-foreground">/month</span></p></div>
            </div>
            <div className="mt-10 rounded-md bg-surface-raised p-5 text-base leading-7">✓ Setup fee refunded if we don&apos;t book you a showing within 48 hours.</div>
            <Button asChild variant="hero" size="hero" className="mt-8 w-full"><a href="#contact">Book a Call</a></Button>
          </div>
        </div>
      </section>

      <section id="about" className="px-5 py-24 sm:px-8 sm:py-32">
        <div className="mx-auto max-w-6xl">
          <h2 data-reveal className="reveal text-4xl font-bold sm:text-5xl">About Me</h2>
          <div data-reveal className="reveal mt-12 grid items-start gap-10 md:grid-cols-[300px_minmax(0,1fr)] md:gap-16">
            <img src={portraitAsset.url} alt="Mohammad Alaaid" width="300" height="300" loading="lazy" className="aspect-square w-full max-w-[300px] rounded-lg border border-border object-cover" />
            <div className="space-y-6 text-lg leading-[1.8] text-muted-foreground">
              <p>I&apos;m Mohammad Alaaid, founder of AI Automation for Realtors.</p>
              <p>Three years ago, I watched a real estate agent lose an $8,000 commission because they missed a call. That single moment changed everything.</p>
              <p>Since then, I&apos;ve built AI systems that solve this exact problem. My voice receptionists answer every call, book showings automatically, and send daily reports. No missed leads. No more lost deals.</p>
              <p>Currently onboarding agents across the US who are tired of leaving money on the table. If you&apos;re losing deals to missed calls, we should talk.</p>
              <p className="text-sm italic text-foreground">— Mohammad</p>
            </div>
          </div>
        </div>
      </section>

      <ContactSection />

      <footer className="border-t border-border/60 px-5 py-16 text-center sm:px-8">
        <h2 className="text-3xl font-bold sm:text-4xl">Questions? Let&apos;s talk.</h2>
        <a href="mailto:mohammadaalaaied@gmail.com" className="mt-6 inline-block break-all text-lg text-foreground underline-offset-4 hover:underline">mohammadaalaaied@gmail.com</a>
        <div className="mx-auto mt-9 flex max-w-md flex-wrap justify-center gap-4">
          {socials.map(({ label, href, icon: Icon }) => (
            <a key={label} href={href} target="_blank" rel="noreferrer" aria-label={label} title={label} className="grid size-10 place-items-center text-social transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
              <Icon aria-hidden="true" className="size-8" />
            </a>
          ))}
        </div>
        <p className="mt-10 text-xs text-social">© 2026 Mohammad Alaaid. AI Automation for Realtors.</p>
      </footer>
    </main>
  );
}

function Navigation() {
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-border/60 bg-background/90 backdrop-blur-xl">
      <nav aria-label="Main navigation" className="mx-auto grid h-16 max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-5 sm:px-8 lg:grid-cols-[1fr_auto_1fr]">
        <a href="#top" className="truncate text-base font-bold sm:text-lg">Mohammad Alaaid</a>
        <div className="hidden items-center gap-7 lg:flex">
          <a href="#what-i-do" className="text-sm text-muted-foreground transition-colors hover:text-foreground">What I Do</a>
          <a href="#pricing" className="text-sm text-muted-foreground transition-colors hover:text-foreground">Pricing</a>
          <a href="#about" className="text-sm text-muted-foreground transition-colors hover:text-foreground">About</a>
          <a href="#contact" className="text-sm text-muted-foreground transition-colors hover:text-foreground">Contact</a>
        </div>
        <Button asChild variant="hero" className="justify-self-end"><a href="#contact">Book a Call</a></Button>
      </nav>
    </header>
  );
}

function ContactSection() {
  const submitContact = useServerFn(submitContactRequest);
  const [status, setStatus] = useState<"idle" | "sending" | "success" | "error">("idle");
  const [error, setError] = useState("");

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formElement = event.currentTarget;
    setStatus("sending");
    setError("");
    const form = new FormData(formElement);
    const payload = {
      name: String(form.get("name") ?? ""),
      email: String(form.get("email") ?? ""),
      phone: String(form.get("phone") ?? ""),
      website: String(form.get("website") ?? ""),
    };

    try {
      await submitContact({ data: payload });
      formElement.reset();
      setStatus("success");
      const subject = encodeURIComponent(`Website inquiry from ${payload.name}`);
      const body = encodeURIComponent(`Name: ${payload.name}\nEmail: ${payload.email}\nPhone: ${payload.phone}`);
      window.setTimeout(() => {
        window.location.href = `mailto:mohammadaalaaied@gmail.com?subject=${subject}&body=${body}`;
      }, 800);
    } catch {
      setStatus("error");
      setError("Something went wrong. Please email me directly.");
    }
  }

  return (
    <section id="contact" className="border-t border-border/60 px-5 py-24 sm:px-8 sm:py-32">
      <div data-reveal className="reveal mx-auto max-w-[500px]">
        <div className="text-center">
          <h2 className="text-4xl font-bold sm:text-5xl">Get in Touch</h2>
          <p className="mt-5 text-lg text-muted-foreground">Questions? I&apos;ll respond within 24 hours.</p>
        </div>
        <form onSubmit={handleSubmit} className="mt-12 space-y-6">
          <div className="hidden" aria-hidden="true"><Label htmlFor="website">Website</Label><Input id="website" name="website" tabIndex={-1} autoComplete="off" /></div>
          <div className="space-y-2"><Label htmlFor="name">Name</Label><Input id="name" name="name" placeholder="Your name" required maxLength={100} className="h-14 bg-surface px-4 text-foreground" /></div>
          <div className="space-y-2"><Label htmlFor="email">Email</Label><Input id="email" name="email" type="email" placeholder="your@email.com" required maxLength={255} className="h-14 bg-surface px-4 text-foreground" /></div>
          <div className="space-y-2"><Label htmlFor="phone">Phone</Label><Input id="phone" name="phone" type="tel" inputMode="tel" placeholder="Your phone number" required minLength={3} maxLength={40} pattern="[+()\-\s\d.]+" className="h-14 bg-surface px-4 text-foreground" /></div>
          <Button type="submit" variant="hero" size="hero" className="w-full" disabled={status === "sending"}>{status === "sending" ? "Sending…" : "Send"}</Button>
          <div aria-live="polite" className="min-h-6 text-center text-sm">
            {status === "success" && <p>Thanks. Expect a call or email within 24 hours.</p>}
            {status === "error" && <p className="text-destructive">{error}</p>}
          </div>
        </form>
      </div>
    </section>
  );
}