import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const contactSchema = z.object({
  name: z.string().trim().min(1).max(100),
  email: z.string().trim().email().max(255),
  phone: z
    .string()
    .trim()
    .min(3)
    .max(40)
    .regex(/^[+()\-\s\d.]+$/),
  website: z.string().max(0),
});

export const submitContactRequest = createServerFn({ method: "POST" })
  .validator((input) => contactSchema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("contact_requests").insert({
      name: data.name,
      email: data.email,
      phone: data.phone,
    });

    if (error) {
      console.error("Contact request failed:", error.message);
      throw new Error("Unable to send your message right now. Please try again.");
    }

    return { ok: true };
  });