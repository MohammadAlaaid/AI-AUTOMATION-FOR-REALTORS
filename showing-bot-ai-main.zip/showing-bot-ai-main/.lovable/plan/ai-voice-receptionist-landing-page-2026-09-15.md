# AI Voice Receptionist Landing Page

## Build
- Replace the placeholder homepage with the exact requested one-page structure: sticky navigation, centered introduction, services, pricing, about, contact form, and footer.
- Use the supplied Mohammad portrait in both requested placements, optimized through the project asset pipeline.
- Match the specified black, white, navy, and gray palette with Inter typography, restrained spacing, and subtle scroll reveals.
- Add responsive navigation and layouts for iPhone 12, iPad, desktop, and wide desktop without horizontal overflow.

## Interactions
- Connect section links and both “Book a Call” actions to the contact area; connect “See How It Works” to the services area.
- Add client-side and server-side validation to the contact form, send submissions to `mohammadaalaaied@gmail.com`, and show the exact success message.
- Use filled social brand icons and verify every external profile URL.

## Technical details
- Enable Lovable Cloud for secure server-side form handling and email delivery.
- Define all visual values as semantic design tokens; avoid runtime-heavy animation libraries.
- Add route-specific title, description, Open Graph, and Twitter metadata.
- Verify the latest build status, rendered image, form behavior, external links, reduced-motion behavior, and responsive layouts at 390px, 768px, 1280px, and 1920px.

## Delivery note
- Direct email delivery requires a verified sending domain. If none is configured, the page and validated form will be completed while final email sending waits for domain setup.
